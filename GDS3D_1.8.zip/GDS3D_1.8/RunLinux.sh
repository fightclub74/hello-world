linux/GDS3D -p techfiles/example.txt -i gds/example.gds
