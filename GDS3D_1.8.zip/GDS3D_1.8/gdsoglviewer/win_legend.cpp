//  GDS3D, a program for viewing GDSII files in 3D.
//  Created by Jasper Velner and Michiel Soer, http://icd.el.utwente.nl
//  Based on code by Roger Light, http://atchoo.org/gds2pov/
//  
//  Copyright (C) 2013 IC-Design Group, University of Twente.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

#include "windowmanager.h"
#include "win_legend.h"

WinLegend::WinLegend()
{
	int i;
	struct ListItem *item = new struct ListItem();

	current_process = wm->getProcess();
	current_layer = NULL;

	SetTitle("Legend");
	SetScreenSize(wm->screenWidth, wm->screenHeight);
	SetPos(20, wm->screenHeight - 400 - 50);
	SetSize(175, 400);
	SetColorBox(true);
	SetVisibility(false);
	SetSingleSelect(false);
	SetSorted(false);

	for (i = 0; i < current_process->LayerCount(); i++) {
		current_layer = current_process->GetLayer(i);

		if (current_layer) {
			if (current_layer->Red > 0.1 || current_layer->Green > 0.1 || current_layer->Blue > 0.1) {
				item->Red = current_layer->Red;
				item->Green = current_layer->Green;
				item->Blue = current_layer->Blue;
				item->Text = current_layer->Name;
				item->Selected = (current_layer->Show == 1);
				AddItem(item);
			}
		}
	}

	if (item)
		delete item;
}

bool WinLegend::Event(int event, int data, int x, int y, bool shift, bool control, bool alt)
{
	class GDSProcess *current_process = wm->getProcess();
	struct ProcessLayer * current_layer = NULL;
	struct EventInfo eventinfo;
	bool block = true;
    
    if( event == 4 ) // Key up
	{
		int numkey = 0;
        
		switch (data) {
            case KEY_9:
                numkey++;
            case KEY_8:
                numkey++;
            case KEY_7:
                numkey++;
            case KEY_6:
                numkey++;
            case KEY_5:
                numkey++;
            case KEY_4:
                numkey++;
            case KEY_3:
                numkey++;
            case KEY_2:
                numkey++;
            case KEY_1:
                numkey++;
            case KEY_0:
                for (int i = 0; i < current_process->LayerCount(); i++) {
                    current_layer = current_process->GetLayer(i);
                    
                    if (current_layer) {
                        if (current_layer->Alt == alt && current_layer->Ctrl == control && current_layer->Shift == shift && current_layer->ShortKey == numkey) {
                            current_layer->Show = !current_layer->Show;
                            GetItem(i)->Selected = current_layer->Show == 1;
						}
					}
				}
			break;
        }
        
    }

    // Implement listview window behavior
	ListView::Event(event, data, x, y, shift, control, alt);
	eventinfo = LastEventInfo();
	wm->change_cursor(eventinfo.EventCursor);

	switch (eventinfo.EventID) {
	case LV_EVENT_NONE:
		//block = (eventinfo.EventCursor != 0);
		block = false;
		break;
	case LV_EVENT_SELECTED_CHANGED:
		if (eventinfo.Item) {
			current_layer = current_process->GetLayer(eventinfo.Item->Index);

			// Set layer visibility
			if (current_layer)
				current_process->ChangeVisibility(current_layer, eventinfo.Item->Selected);
		}
	case LV_EVENT_STATE_CHANGED:
	case LV_EVENT_CLICK:
	case LV_EVENT_SCROLL:
	default:
		break;
	}

	return block;
}

void WinLegend::Draw()
{
	// Update the visibility status of the layers
	struct ListItem *legenditem = NULL;
	struct ProcessLayer * current_layer = NULL;

	legenditem = GetFirst();
	while (legenditem) {
		current_layer = wm->getProcess()->GetLayer(legenditem->Index);
		if(current_layer)
			legenditem->Selected = (current_layer->Show == 1);
                    
		legenditem = legenditem->NextItem;
	}

	// Draw the listview
	ListView::Draw();
}