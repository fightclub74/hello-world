# GDS3D
This is a fork from https://sourceforge.net/projects/gds3d.

The original developers and maintainers of GDS3D on sourceforge.net agreed to continue hosting the project on GitHub in order to be more accessible to developers. You are invited to propose features and report issues on this GitHub portal. 

If you want to help maintaining the project, feel free to contact me.

Since the creation of this repository in May, 2017 a few features have been added. See the Issue Tracker for more details.
